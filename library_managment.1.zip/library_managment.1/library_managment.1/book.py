class Book:
    def __init__(self, title, author):
        # Initialises a Book object with a title and author
        self.title = title.strip()
        self.author = author.strip()

    def __str__(self):
        # Returns a string representation of the Book object
        return f"'{self.title}' by {self.author}"
