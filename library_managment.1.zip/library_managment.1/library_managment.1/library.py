class Library:
    """
    A class to represent a library.

    Attributes:
        books (list): A list of books in the library.
        members (list): A list of members in the library.
    """

    def __init__(self, initial_books=None):
        """
        Initializes a Library instance with optional initial books and an empty list of members.

        Args:
            initial_books (list, optional): A list of Book objects to prepopulate the library.
        """
        self.books = initial_books if initial_books else []  # Initialise with given books or empty list
        self.members = []  # List to store registered library members

    def add_book(self, book):
        """
        Adds a book to the library's collection.
        """
        if book in self.books:
            print(f"The book {book} is already in the library.")
        else:
            self.books.append(book)
            print(f"Added {book} to the library.")

    def borrow_book(self, member, book):
        """
        Allows a member to borrow a book from the library.
        """
        if book in self.books:
            member.borrow_book(book)
            self.books.remove(book)
            print(f"{member.name} borrowed {book}.")
        else:
            print(f"{book} is not available in the library.")

    def return_book(self, member, book):
        """
        Handles the return of a borrowed book by a member.
        """
        if book in member.borrowed_books:
            member.return_book(book)
            self.books.append(book)
            print(f"Thanks for returning {book}, {member.name}!")
        else:
            print(f"{member.role} {member.name} has not borrowed {book}.")

    def register_member(self, member):
        """
        Registers a new member in the library.
        """
        if member in self.members:
            print(f"Member {member.name} is already registered.")
        else:
            self.members.append(member)
            print(f"Registered member: {member.name}.")

    def __str__(self):
        """
        Returns a string representation of the library's contents.
        """
        books = ', '.join(str(book) for book in self.books) or "No books available."
        members = ', '.join(member.name for member in self.members) or "No members yet."
        return f"Library contains books: [{books}] and members: [{members}]"
