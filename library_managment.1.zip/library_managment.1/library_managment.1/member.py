class Member:
    """
    A class to represent a library member.

    Attributes:
        name (str): The name of the member.
        borrowed_books (list): A list of books borrowed by the member.
        role (str): The role of the member (e.g., Student or Teacher).
    """

    def __init__(self, name, role):
        """
        Initializes a Member instance.

        Args:
            name (str): The name of the member.
            role (str): The role of the member (e.g., Student or Teacher).
        """
        self.name = name.strip()  # Remove any leading or trailing whitespace from the name
        self.borrowed_books = []  # Initialize an empty list to store borrowed books
        self.role = role  # Set the role of the member (Student or Teacher)

    def borrow_book(self, book):
        """
        Allows the member to borrow a book.

        Args:
            book (Book): The book to be borrowed.
        """
        if book in self.borrowed_books:  # Check if the book is already borrowed by the member
            print(f"{self.role} {self.name} already borrowed {book}.")  # Notify if already borrowed
        else:
            self.borrowed_books.append(book)  # Add the book to the member's borrowed list
            print(f"{self.role} {self.name} borrowed {book}.")  # Confirm the borrowing action

    def return_book(self, book):
        """
        Allows the member to return a borrowed book.

        Args:
            book (Book): The book to be returned.
        """
        if book in self.borrowed_books:  # Check if the book is in the member's borrowed list
            self.borrowed_books.remove(book)  # Remove the book from the borrowed list
            print(f"{self.role} {self.name} returned {book}.")  # Confirm the return action
        else:
            print(f"{self.role} {self.name} has not borrowed {book}.")  # Notify if the book was not borrowed

    def __str__(self):
        """
        Returns a string representation of the member.

        Returns:
            str: The member's role, name, and a list of borrowed books.
        """
        # Create a string of borrowed books or indicate "No books borrowed."
        borrowed = ', '.join(str(book) for book in self.borrowed_books) or "No books borrowed."
        return f"{self.role}: {self.name}, Borrowed Books: [{borrowed}]"


class Student(Member):
    """
    A subclass of Member representing a Student.

    Inherits:
        Member: The base class for library members.
    """

    def __init__(self, name):
        """
        Initializes a Student instance.

        Args:
            name (str): The name of the student.
        """
        super().__init__(name, "Student")  # Call the parent constructor with the role "Student"


class Teacher(Member):
    """
    A subclass of Member representing a Teacher.

    Inherits:
        Member: The base class for library members.
    """

    def __init__(self, name):
        """
        Initializes a Teacher instance.

        Args:
            name (str): The name of the teacher.
        """
        super().__init__(name, "Teacher")  # Call the parent constructor with the role "Teacher"
