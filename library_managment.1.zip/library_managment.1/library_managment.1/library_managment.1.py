from library import Library  # Import the Library class to manage the library system
from book import Book  # Import the Book class to represent individual books
from member import Student, Teacher  # Import the Student and Teacher classes for user roles


def main():
    """
    Main function to run the Library Management System.
    Handles user interaction and manages library operations.
    """

    # Prepopulate the library with some books
    pre_existing_books = [
        Book("1984", "George Orwell"),  # A classic book by George Orwell
        Book("To Kill a Mockingbird", "Harper Lee"),  # A classic book by Harper Lee
        Book("The Great Gatsby", "F. Scott Fitzgerald"),  # A classic book by F. Scott Fitzgerald
        Book("Moby Dick", "Herman Melville")  # A classic book by Herman Melville
    ]

    # Create the Library instance with the pre-existing books
    library = Library(initial_books=pre_existing_books)

    # Welcome message for the user
    print("Welcome to the Library Management System!")

    # Get the user's name
    while True:
        name = input("Enter your name: ").strip()  # Prompt the user to enter their name
        if name:  # Ensure the name is not empty
            break
        print("Name cannot be empty. Please try again.")  # Notify the user if input is invalid

    # Check if the user is already a registered member
    existing_member = next((m for m in library.members if m.name == name), None)

    if existing_member:
        # Welcome back the returning member
        print(f"Welcome back, {existing_member.role} {existing_member.name}!")
    else:
        # If the user is new, prompt for registration
        print("It seems you are new here.")
        while True:
            role = input("Are you a Student or a Teacher? ").strip().lower()  # Ask the user's role
            if role in ["student", "teacher"]:  # Ensure the role is valid
                break
            print("Invalid role. Please enter 'Student' or 'Teacher'.")  # Notify if role is invalid

        # Register the user based on their role
        if role == "student":
            new_member = Student(name)  # Create a new Student member
        else:
            new_member = Teacher(name)  # Create a new Teacher member

        library.register_member(new_member)  # Register the new member in the library
        existing_member = new_member  # Set the user as the current member
        print(f"Registration successful. Welcome, {existing_member.role} {existing_member.name}!")  # Confirm registration

    # Library menu loop
    while True:
        # Display menu options for the user
        print(f"\nHello, {existing_member.role} {existing_member.name}. What would you like to do?")
        print("1. Add a Book (For Librarian Use Only)")  # Option to add a new book
        print("2. Borrow a Book")  # Option to borrow a book
        print("3. Return a Book")  # Option to return a borrowed book
        print("4. View Library Status")  # Option to view library details
        print("5. Exit")  # Option to exit the system

        # Get the user's menu choice
        choice = input("Enter your choice (1-5): ").strip()

        if choice == "1":
            # Option to add a book (only for Teachers)
            if isinstance(existing_member, Teacher):  # Check if the member is a Teacher
                # Get book details from the user
                title = input("Enter the title of the book: ").strip()
                author = input("Enter the author of the book: ").strip()
                book = Book(title, author)  # Create a new book object
                library.add_book(book)  # Add the book to the library
            else:
                print("Only teachers can add books to the library.")  # Restrict access for non-teachers

        elif choice == "2":
            # Option to borrow a book
            if not library.books:  # Check if the library has any books available
                print("The library has no books to borrow.")  # Notify the user if no books are available
            else:
                print("\nAvailable books in the library:")  # List available books
                for idx, book in enumerate(library.books, start=1):
                    print(f"{idx}. {book}")
                title = input("Enter the title of the book you want to borrow: ").strip()  # Get the book title
                book = next((b for b in library.books if b.title.lower() == title.lower()), None)  # Find the book
                if book:
                    library.borrow_book(existing_member, book)  # Borrow the book
                else:
                    print(f"Sorry, the book '{title}' is not available.")  # Notify if the book is unavailable

        elif choice == "3":
            # Option to return a borrowed book
            if not existing_member.borrowed_books:  # Check if the member has borrowed any books
                print(f"You have not borrowed any books. Nothing to return.")  # Notify if no books to return
            else:
                title = input("Enter the title of the book to return: ").strip()  # Get the book title
                book = next((b for b in existing_member.borrowed_books if b.title.lower() == title.lower()), None)
                if book:
                    library.return_book(existing_member, book)  # Return the book
                else:
                    print(f"You did not borrow a book with the title '{title}'.")  # Notify if book not found

        elif choice == "4":
            # Option to view library status
            print("\nLibrary Status:")
            print(library)  # Display library details

        elif choice == "5":
            # Exit the system
            print("Goodbye!")  # Farewell message
            break

        else:
            # Handle invalid input
            print("Invalid choice. Please enter a number between 1 and 5.")


# Entry point of the program
if __name__ == "__main__":
    main()  # Run the main function
