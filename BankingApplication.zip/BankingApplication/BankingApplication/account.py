class Account:
    """
    A base class to represent a generic bank account.
    Provides core functionalities like deposit, withdrawal, and balance management.
    """

    def __init__(self, account_number, customer_id, balance=0.0):
        """
        Initialises an Account instance.

        Args:
            account_number (str): The unique account number for this account.
            customer_id (str): The ID of the customer who owns this account.
            balance (float, optional): The initial balance for the account. Defaults to 0.0.
        """
        self._account_number = account_number  # Stores the account number
        self._customer_id = customer_id  # Stores the ID of the account owner
        self._balance = balance  # Stores the account balance

    def deposit(self, amount):
        """
        Deposits a specified amount into the account.

        Args:
            amount (float): The amount to deposit. Must be greater than zero.

        Returns:
            str: A confirmation message with the deposited amount and new balance.

        Raises:
            ValueError: If the deposit amount is not greater than zero.
        """
        if amount > 0:
            self._balance += amount  # Increase the balance by the deposit amount
            return f"Deposited {amount:.2f}. New Balance: {self._balance:.2f}"
        raise ValueError("Deposit amount must be greater than zero.")  # Raise error for invalid amounts

    def withdraw(self, amount):
        """
        Withdraws a specified amount from the account.

        Args:
            amount (float): The amount to withdraw. Must be greater than zero and less than or equal to the current balance.

        Returns:
            str: A confirmation message with the withdrawn amount and remaining balance.

        Raises:
            ValueError: If the withdrawal amount is not greater than zero or if funds are insufficient.
        """
        if amount <= 0:
            raise ValueError("Withdrawal amount must be greater than zero.")  # Validate positive amount
        if amount > self._balance:
            raise ValueError("Insufficient funds.")  # Validate sufficient balance
        self._balance -= amount  # Decrease the balance by the withdrawal amount
        return f"Withdrew {amount:.2f}. Remaining Balance: {self._balance:.2f}"

    def get_balance(self):
        """
        Retrieves the current balance of the account.

        Returns:
            float: The current account balance.
        """
        return self._balance

    def get_account_number(self):
        """
        Retrieves the account number.

        Returns:
            str: The account number.
        """
        return self._account_number
