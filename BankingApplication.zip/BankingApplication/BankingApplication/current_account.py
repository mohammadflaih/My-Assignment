from account import Account  # Import the base Account class

class CurrentAccount(Account):
    """
    Represents a Current Account, inheriting from the base Account class.
    Current accounts typically allow for everyday banking transactions.
    """

    def __init__(self, account_number, customer_id, balance=0.0):
        """
        Initializes a CurrentAccount instance.

        Args:
            account_number (str): The unique account number for this current account.
            customer_id (str): The ID of the customer who owns this account.
            balance (float, optional): The initial balance for the account. Defaults to 0.0.
        """
        # Initialize the base Account class with provided details
        super().__init__(account_number, customer_id, balance)
