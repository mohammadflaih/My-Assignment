from savings_account import SavingsAccount  # Import SavingsAccount class
from current_account import CurrentAccount  # Import CurrentAccount class
from mortgage_account import MortgageAccount  # Import MortgageAccount class
from datetime import datetime  # Import for date validation

class Customer:
    """
    Represents a bank customer who can own multiple accounts and perform actions like account creation and viewing details.
    """

    def __init__(self, name, address, dob, username, password, sort_code):
        """
        Initializes a Customer instance with personal details and associated accounts.

        Args:
            name (str): Customer's name.
            address (str): Customer's address.
            dob (str): Date of Birth in YYYY-MM-DD format.
            username (str): Chosen username for the customer.
            password (str): Chosen password for the customer.
            sort_code (str): The sort code assigned to the customer.

        Raises:
            ValueError: If the date of birth is not in the correct format.
        """
        # Validate the date of birth format
        try:
            datetime.strptime(dob, "%Y-%m-%d")
        except ValueError:
            raise ValueError("Date of Birth must be in YYYY-MM-DD format.")
        
        # Initialize customer attributes
        self._customer_id = username[:3].upper() + "123"  # Generate a simple customer ID
        self._name = name
        self._address = address
        self._dob = dob
        self._username = username
        self._password = password
        self._sort_code = sort_code
        self._accounts = []  # List to hold accounts associated with the customer

    def create_account(self, account_type, initial_balance, bank):
        """
        Creates a new account for the customer and adds it to the bank.

        Args:
            account_type (str): The type of account to create ('savings', 'current', or 'mortgage').
            initial_balance (float): The initial deposit or loan amount for the account.
            bank (Bank): The bank object to associate the account with.

        Returns:
            str: A success message indicating the account type and number.

        Raises:
            ValueError: If the account type is invalid.
        """
        # Generate a unique account number
        account_number = bank.generate_account_number()

        # Create the specified type of account
        if account_type.lower() == "savings":
            account = SavingsAccount(account_number, self._customer_id, initial_balance)
        elif account_type.lower() == "current":
            account = CurrentAccount(account_number, self._customer_id, initial_balance)
        elif account_type.lower() == "mortgage":
            # For mortgage accounts, initial_balance represents the loan amount
            account = MortgageAccount(account_number, self._customer_id, loan_amount=initial_balance, interest_rate=5.0)
        else:
            raise ValueError("Invalid account type.")  # Raise error for unsupported account types

        # Add the account to the customer's account list and the bank's account registry
        self._accounts.append(account)
        bank.add_account(account)
        return f"{account_type.capitalize()} account {account_number} created successfully."

    def view_details(self):
        """
        Views the customer's details, including personal information and account summary.

        Returns:
            str: A formatted string of the customer's details and associated accounts.
        """
        # Format customer details
        details = f"""
        Name: {self._name}
        Address: {self._address}
        Date of Birth: {self._dob}
        Sort Code: {self._sort_code}
        Accounts:
        """
        # Append account details to the output
        for acc in self._accounts:
            # Determine the type of each account
            account_type = (
                "Savings" if isinstance(acc, SavingsAccount)
                else "Current" if isinstance(acc, CurrentAccount)
                else "Mortgage"
            )
            details += f"""
            - Account Type: {account_type}
              Account Number: {acc.get_account_number()}
              Balance: {acc.get_balance():.2f}
            """
        return details

    def validate_credentials(self, username, password):
        """
        Validates the customer's username and password.

        Args:
            username (str): The entered username.
            password (str): The entered password.

        Returns:
            bool: True if the credentials match; otherwise, False.
        """
        return self._username == username and self._password == password
