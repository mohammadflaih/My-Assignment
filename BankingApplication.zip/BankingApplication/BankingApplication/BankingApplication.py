from bank import Bank  # Importing the Bank class
from utils import masked_input  # Utility function for secure input
from savings_account import SavingsAccount  # Importing SavingsAccount class
from current_account import CurrentAccount  # Importing CurrentAccount class
from mortgage_account import MortgageAccount  # Importing MortgageAccount class


def main():
    # Initializes a Bank instance
    bank = Bank("LLOYDS Bank", "123 Finance St", "support@lloydsbank.com")
    logged_in_customer = None  # Tracks the currently logged-in customer

    while True:
        # If no customer is logged in, show the main menu
        if not logged_in_customer:
            print("\n--- Welcome to LLOYDS Bank ---")
            print("1. Open an Account")
            print("2. Login")
            print("3. Exit")
            choice = input("Enter your choice: ").strip()

            if choice == "1":  # Open an account
                name = input("Enter your name: ").strip()
                address = input("Enter your address: ").strip()
                dob = input("Enter your date of birth (YYYY-MM-DD): ").strip()
                username = input("Choose a username: ").strip()
                password = masked_input("Enter your password: ")  # Secure input for password

                try:
                    # Create a new customer and add an initial account
                    customer = bank.add_customer(name, address, dob, username, password)
                    initial_balance = float(input("Enter the initial deposit amount for your current account: "))
                    print(customer.create_account("current", initial_balance, bank))
                    print(customer.view_details())  # Show customer details
                except ValueError as e:
                    print(f"Error: {e}")

            elif choice == "2":  # Login
                username = input("Enter your username: ").strip()
                password = masked_input("Enter your password: ").strip()
                # Find the customer by credentials
                customer = bank.find_customer_by_credentials(username, password)
                if customer:
                    logged_in_customer = customer
                    print(f"Welcome back, {customer._name}!")
                else:
                    print("Invalid username or password.")

            elif choice == "3":  # Exit the program
                print("Thank you for banking with us. Goodbye!")
                break

        else:
            # If a customer is logged in, show their options
            print(f"\nWelcome, {logged_in_customer._name}!")
            print("1. Add Balance")
            print("2. Check Balance")
            print("3. Withdraw Money")
            print("4. Open a Savings Account")
            print("5. Open a Mortgage Account")
            print("6. Transfer Money")
            print("7. View My Details")
            print("8. Mortgage Account Options")
            print("9. Logout")
            choice = input("Enter your choice: ").strip()

            if choice == "1":  # Add balance to an account
                print("\n--- Add Balance ---")
                try:
                    # Display all accounts and their balances
                    accounts = logged_in_customer._accounts
                    for i, acc in enumerate(accounts, start=1):
                        account_type = (
                            "Savings" if isinstance(acc, SavingsAccount)
                            else "Current" if isinstance(acc, CurrentAccount)
                            else "Mortgage"
                        )
                        print(f"{i}. {account_type} Account ({acc.get_account_number()}), Balance: {acc.get_balance():.2f}")

                    selected_account = int(input("Select an account to add balance (by number): "))
                    account = accounts[selected_account - 1]
                    amount = float(input("Enter the amount to deposit: "))
                    print(account.deposit(amount))  # Deposit the amount into the selected account
                except (ValueError, IndexError) as e:
                    print(f"Error: {e}")

            elif choice == "2":  # Check account balance
                print("\n--- Check Balance ---")
                try:
                    # Display all accounts
                    accounts = logged_in_customer._accounts
                    for i, acc in enumerate(accounts, start=1):
                        account_type = (
                            "Savings" if isinstance(acc, SavingsAccount)
                            else "Current" if isinstance(acc, CurrentAccount)
                            else "Mortgage"
                        )
                        print(f"{i}. {account_type} Account ({acc.get_account_number()})")

                    selected_account = int(input("Select an account to check balance (by number): "))
                    account = accounts[selected_account - 1]
                    print(f"Balance: {account.get_balance():.2f}")  # Show the balance of the selected account
                except (ValueError, IndexError) as e:
                    print(f"Error: {e}")

            elif choice == "3":  # Withdraw money from an account
                print("\n--- Withdraw Money ---")
                try:
                    # Display all accounts and their balances
                    accounts = logged_in_customer._accounts
                    for i, acc in enumerate(accounts, start=1):
                        account_type = (
                            "Savings" if isinstance(acc, SavingsAccount)
                            else "Current" if isinstance(acc, CurrentAccount)
                            else "Mortgage"
                        )
                        print(f"{i}. {account_type} Account ({acc.get_account_number()}), Balance: {acc.get_balance():.2f}")

                    selected_account = int(input("Select an account to withdraw from (by number): "))
                    account = accounts[selected_account - 1]
                    amount = float(input("Enter the amount to withdraw: "))
                    print(account.withdraw(amount))  # Withdraw the amount from the selected account
                except (ValueError, IndexError) as e:
                    print(f"Error: {e}")

            elif choice == "4":  # Open a savings account
                print("\n--- Open a Savings Account ---")
                try:
                    initial_balance = float(input("Enter the initial deposit amount: "))
                    print(logged_in_customer.create_account("savings", initial_balance, bank))  # Create a savings account
                except ValueError as e:
                    print(f"Error: {e}")

            elif choice == "5":  # Open a mortgage account
                print("\n--- Open a Mortgage Account ---")
                try:
                    print("5% Interest Rate Will be Applied On The Mortgage")
                    loan_amount = float(input("Enter the loan amount: "))
                    print(logged_in_customer.create_account("mortgage", loan_amount, bank))  # Create a mortgage account
                except ValueError as e:
                    print(f"Error: {e}")

            elif choice == "6":  # Transfer money between accounts
                print("\n--- Transfer Money ---")
                try:
                    print("\nAvailable Accounts for Transfer:")
                    print(bank.list_all_accounts())  # Display all accounts

                    from_account = input("Enter source account number: ").strip()
                    to_account = input("Enter destination account number: ").strip()
                    amount = float(input("Enter amount to transfer: "))
                    print(bank.transfer_money(from_account, to_account, amount))  # Perform the transfer
                except ValueError as e:
                    print(f"Error: {e}")

            elif choice == "7":  # View customer details
                print("\n--- View My Details ---")
                print(logged_in_customer.view_details())  # Show customer details

            elif choice == "8":  # Mortgage account options
                print("\n--- Mortgage Account Options ---")
                try:
                    # Display all mortgage accounts
                    accounts = [acc for acc in logged_in_customer._accounts if isinstance(acc, MortgageAccount)]
                    if not accounts:
                        print("No mortgage accounts found.")
                        continue
                    for i, acc in enumerate(accounts, start=1):
                        print(f"{i}. Mortgage Account ({acc.get_account_number()}), Loan Amount: {acc._loan_amount:.2f}")

                    selected_account = int(input("Select a mortgage account (by number): "))
                    mortgage_account = accounts[selected_account - 1]

                    # Mortgage account-specific options
                    print("1. View Loan Details")
                    print("2. Make a Payment")
                    print("3. Calculate Monthly Payments")
                    mortgage_choice = input("Enter your choice: ").strip()

                    if mortgage_choice == "1":
                        print(mortgage_account.get_loan_details())  # View loan details
                    elif mortgage_choice == "2":
                        amount = float(input("Enter the payment amount: "))
                        print(mortgage_account.deposit(amount))  # Make a payment
                    elif mortgage_choice == "3":
                        months = int(input("Enter the number of months for repayment: "))
                        print(mortgage_account.calculate_monthly_payment(months))  # Calculate monthly payments
                    else:
                        print("Invalid choice.")
                except (ValueError, IndexError) as e:
                    print(f"Error: {e}")

            elif choice == "9":  # Logout
                print("\nYou have been logged out.")
                logged_in_customer = None  # Reset the logged-in customer


if __name__ == "__main__":
    main()  # Entry point of the application
