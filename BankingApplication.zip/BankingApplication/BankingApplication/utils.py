import sys  # Module for system-specific parameters and functions
import msvcrt  # Windows-specific module for keyboard input handling

def masked_input(prompt=""):
    """
    Custom input function to mask user input with '*' while typing.
    This function works only on Windows due to its reliance on the `msvcrt` module.

    Args:
        prompt (str): The prompt text to display before accepting input.

    Returns:
        str: The user-entered password, with characters masked during entry.
    """
    print(prompt, end="", flush=True)  # Display the prompt without a newline
    password = ""  # Initialize the password variable to store user input

    while True:
        char = msvcrt.getch()  # Read a single character from the keyboard
        if char in {b"\r", b"\n"}:  # Check if the Enter key was pressed
            if not password:  # Ensure the password is not empty
                print("\nPassword cannot be empty. Please try again.")  # Error message
                print(prompt, end="", flush=True)  # Redisplay the prompt
                continue
            print()  # Move to the next line after successful input
            break
        elif char == b"\x08":  # Check if the Backspace key was pressed
            if password:  # Ensure there are characters to delete
                password = password[:-1]  # Remove the last character from the password
                sys.stdout.write("\b \b")  # Remove the last '*' from the console
                sys.stdout.flush()  # Ensure changes are reflected immediately
        else:
            # Append the character to the password after decoding it from bytes to a string
            password += char.decode("utf-8")
            sys.stdout.write("*")  # Display a '*' to mask the character
            sys.stdout.flush()  # Ensure the '*' appears immediately
    return password  # Return the user-entered password
