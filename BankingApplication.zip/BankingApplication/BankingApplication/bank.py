import random  # Module for generating random numbers
from savings_account import SavingsAccount  # Import SavingsAccount class
from current_account import CurrentAccount  # Import CurrentAccount class
from mortgage_account import MortgageAccount  # Import MortgageAccount class
from customer import Customer  # Import Customer class

class Bank:
    """
    Represents a Bank that manages customers and their accounts.
    Provides functionalities like adding customers, creating accounts, 
    transferring money, and listing all accounts.
    """

    def __init__(self, name, address, contact):
        """
        Initializes the Bank instance with basic details and storage structures.

        Args:
            name (str): The name of the bank.
            address (str): The address of the bank.
            contact (str): The contact information for the bank.
        """
        self._name = name  # Name of the bank
        self._address = address  # Bank's address
        self._contact = contact  # Bank's contact information
        self._customers = {}  # Dictionary to store customers by customer ID
        self._accounts = {}  # Dictionary to store accounts by account number

    def generate_account_number(self):
        """
        Generates a random 8-digit account number.
        
        Returns:
            str: A randomly generated account number.
        """
        return f"{random.randint(10000000, 99999999)}"

    def generate_sort_code(self):
        """
        Generates a random 6-digit sort code.

        Returns:
            str: A randomly generated sort code.
        """
        return f"{random.randint(100000, 999999)}"

    def add_customer(self, name, address, dob, username, password):
        """
        Adds a new customer to the bank.

        Args:
            name (str): Customer's name.
            address (str): Customer's address.
            dob (str): Customer's date of birth.
            username (str): Chosen username for the customer.
            password (str): Chosen password for the customer.

        Returns:
            Customer: The newly created customer object.

        Raises:
            ValueError: If the username already exists.
        """
        # Check if the username already exists
        if username in [customer._username for customer in self._customers.values()]:
            raise ValueError("Username already exists.")
        # Generate a unique sort code and create a new customer object
        sort_code = self.generate_sort_code()
        customer = Customer(name, address, dob, username, password, sort_code)
        # Add the customer to the bank's customer dictionary
        self._customers[customer._customer_id] = customer
        return customer

    def add_account(self, account):
        """
        Adds a new account to the bank.

        Args:
            account: The account object to be added.

        Raises:
            ValueError: If the account number already exists.
        """
        # Check if the account number already exists
        if account.get_account_number() in self._accounts:
            raise ValueError("Account number already exists.")
        # Add the account to the bank's account dictionary
        self._accounts[account.get_account_number()] = account

    def find_customer_by_credentials(self, username, password):
        """
        Finds a customer based on their username and password.

        Args:
            username (str): The username to search for.
            password (str): The password to validate.

        Returns:
            Customer: The matching customer object, or None if not found.
        """
        # Iterate through all customers to find a matching username and password
        for customer in self._customers.values():
            if customer.validate_credentials(username, password):
                return customer
        return None

    def transfer_money(self, from_account_number, to_account_number, amount):
        """
        Transfers money between two accounts.

        Args:
            from_account_number (str): The source account number.
            to_account_number (str): The destination account number.
            amount (float): The amount to transfer.

        Returns:
            str: A success message indicating the transfer details.

        Raises:
            ValueError: If any account number is invalid or insufficient funds.
        """
        # Retrieve source and destination accounts
        from_account = self._accounts.get(from_account_number)
        to_account = self._accounts.get(to_account_number)
        if not from_account or not to_account:
            raise ValueError("Invalid account number.")
        if from_account.get_balance() < amount:
            raise ValueError("Insufficient funds in the source account.")
        # Perform the transfer
        from_account.withdraw(amount)
        to_account.deposit(amount)
        return f"Successfully transferred {amount:.2f} from {from_account_number} to {to_account_number}."

    def list_all_accounts(self):
        """
        Lists all accounts registered in the bank.

        Returns:
            str: A formatted string with details of all accounts, or a message if none exist.
        """
        if not self._accounts:
            return "No accounts found."  # Return message if no accounts exist

        # Generate a formatted list of all accounts
        details = "Registered Accounts:\n"
        for account_number, account in self._accounts.items():
            # Determine account type based on its class
            account_type = (
                "Savings" if isinstance(account, SavingsAccount)
                else "Current" if isinstance(account, CurrentAccount)
                else "Mortgage"
            )
            # Append account details to the list
            details += (
                f"Account Type: {account_type}, "
                f"Account Number: {account_number}, "
                f"Balance: {account.get_balance():.2f}\n"
            )
        return details
