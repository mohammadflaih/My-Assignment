from account import Account

# Defines a class MortgageAccount that inherits from the Account class
class MortgageAccount(Account):
    def __init__(self, account_number, customer_id, balance=0.0, interest_rate=5.0, loan_amount=0.0):
        # Initializes the MortgageAccount object using the parent class's constructor
        super().__init__(account_number, customer_id, balance)
        # Sets the interest rate and initial loan amount
        self._interest_rate = interest_rate
        self._loan_amount = loan_amount

    # Method to make a deposit, primarily used for paying off the loan
    def deposit(self, amount):
        if amount > 0:  # Validates the deposit amount
            self._balance += amount  # Updates the account balance
            self._loan_amount -= amount  # Reduces the loan amount by the deposit
            if self._loan_amount < 0:  # Ensures the loan amount doesn't go negative
                self._loan_amount = 0
            # Returns a summary of the payment and current account details
            return f"Payment of {amount:.2f} made. Remaining Loan Balance: {self._loan_amount:.2f}, Account Balance: {self._balance:.2f}"
        raise ValueError("Deposit amount must be greater than zero.")  # Raises an error for invalid deposits

    # Method to withdraw funds from the account balance
    def withdraw(self, amount):
        if amount <= 0:  # Validates that the withdrawal amount is positive
            raise ValueError("Withdrawal amount must be greater than zero.")
        if amount > self._balance:  # Checks if sufficient funds are available
            raise ValueError("Insufficient funds in the account balance.")
        self._balance -= amount  # Deducts the amount from the balance
        # Returns a summary of the withdrawal and remaining balance
        return f"Withdrew {amount:.2f}. Remaining Balance: {self._balance:.2f}"

    # Method to retrieve loan details, including loan amount, interest rate, and balance
    def get_loan_details(self):
        return f"Loan Amount: {self._loan_amount:.2f}, Interest Rate: {self._interest_rate:.2f}%, Account Balance: {self._balance:.2f}"

    # Method to calculate the monthly payment required to repay the loan over a specified number of months
    def calculate_monthly_payment(self, months):
        if months <= 0:  # Validates that the number of months is positive
            raise ValueError("Number of months must be greater than zero.")
        if self._loan_amount <= 0:  # Checks if there's an outstanding loan amount
            return "No outstanding loan amount."
        # Calculates the monthly interest rate
        monthly_rate = self._interest_rate / 100 / 12
        # Calculates the monthly payment using the formula for an amortizing loan
        payment = (self._loan_amount * monthly_rate) / (1 - (1 + monthly_rate) ** -months)
        # Returns the calculated monthly payment
        return f"Monthly Payment for {months} months: {payment:.2f}"
